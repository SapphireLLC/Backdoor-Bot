package llc.sapphire.backdoorbot.monitoring;

import llc.sapphire.backdoorbot.Main;
import net.dv8tion.jda.api.entities.Guild;

import java.util.List;

public class GuildSelections {

    public static List<Guild> getCurrentGuilds(){

        return Main.jda.getGuilds();
    }

}
