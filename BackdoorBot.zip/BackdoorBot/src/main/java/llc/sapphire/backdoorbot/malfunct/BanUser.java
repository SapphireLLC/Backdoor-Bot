package llc.sapphire.backdoorbot.malfunct;

import llc.sapphire.backdoorbot.Main;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.UserSnowflake;

public class BanUser {

    private static JDA jda = Main.jda;

    public BanUser(long userID, long guildID, int timeFrame){
        Guild guild = jda.getGuildById(guildID);
        Member targetMember = guild.getMemberById(userID);

        targetMember.ban(timeFrame, null);
    }

    public static void unbanUser(long snowflake, long guildID){
        Guild guild = jda.getGuildById(guildID);

        guild.unban(UserSnowflake.fromId(snowflake));
    }
}
