package llc.sapphire.backdoorbot.UI;

import javax.swing.*;
import java.awt.*;

public class SplashScreen {

    public SplashScreen(){
        JFrame frame = new JFrame("BackdoorBot V1");
        frame.setSize(400,400);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
