package llc.sapphire.backdoorbot;

import llc.sapphire.backdoorbot.UI.SplashScreen;
import llc.sapphire.backdoorbot.monitoring.GuildSelections;
import llc.sapphire.backdoorbot.monitoring.MessageListener;
import llc.sapphire.backdoorbot.monitoring.SlashListener;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.requests.restaction.CommandListUpdateAction;

import java.util.List;

public class Main {

    public static String userHome;
    public static JDA jda;

    public static void main(String[] args) throws Exception {
        //Get runtime ver
        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("java.vendor"));

        userHome = System.getProperty("user.home") + "\\Documents";

        //Initialize the framework
        initJDAFramework("");
        initBackend();
        initInterface();
    }

    private static void initJDAFramework(String token) throws Exception {
        //Startup and authenticate
        jda = JDABuilder.createDefault(token).addEventListeners(new MessageListener()).addEventListeners(new SlashListener()).enableIntents(GatewayIntent.GUILD_MESSAGES, GatewayIntent.MESSAGE_CONTENT).build();
        //Now that the bot is online, the fun can begin lol

        List<Guild> guilds = GuildSelections.getCurrentGuilds();

        System.out.println(guilds.size());

        CommandListUpdateAction commands = jda.updateCommands();

        //commands.addCommands(
               // Commands.slash("COMMAND_NAME", "DESCRIPTION OF COMMAND")
       // );
    }

    private static void initInterface(){
        new SplashScreen();
    }

    private static void initBackend(){

    }

    /*
    username + ID: message contents


    * *\
     */

}
