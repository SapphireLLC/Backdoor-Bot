package llc.sapphire.backdoorbot.UI;

public class MainWindow {

    //Construct the class and startup the interface
    public MainWindow(){

    }

}
