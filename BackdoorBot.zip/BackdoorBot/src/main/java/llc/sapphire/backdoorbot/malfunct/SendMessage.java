package llc.sapphire.backdoorbot.malfunct;

import llc.sapphire.backdoorbot.Main;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.utils.messages.MessageCreateData;

public class SendMessage {

    private static JDA jda = Main.jda;

    public SendMessage(String message, String channelID, String guildID){
        Guild guild = jda.getGuildById(guildID);

        TextChannel textChannel = guild.getTextChannelById(channelID);

        if(textChannel != null){
            textChannel.sendMessage(MessageCreateData.fromContent(message));
        }else{
            System.err.println("text channel not found, maybe the wrong ID? Maybe you're just a dumbass, I don't know you.");
        }
    }

}
