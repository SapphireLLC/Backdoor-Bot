package llc.sapphire.backdoorbot.monitoring;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class SlashListener extends ListenerAdapter {

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event){
        String command = String.valueOf(event);

        if(command == "COMMAND NAME"){
            //This is where the code the command will trigger goes
        }
    }

}
