package llc.sapphire.backdoorbot.malfunct;

public class GetGuildInvite {



}
