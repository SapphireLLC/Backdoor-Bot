package llc.sapphire.backdoorbot.io;

import java.io.File;

public class FileOps {

    public static void createDir(String filePath){

        File file = new File(filePath);
        file.mkdir();
    }

}
